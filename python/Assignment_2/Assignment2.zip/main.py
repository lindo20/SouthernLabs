# author: lindokuhle Dubazane
import assignment2


def main():
    assignment2.write_countries_capitals_to_file("0123456789.txt")
    assignment2.save_filtered_places()


if __name__ == "__main__":
    main()
