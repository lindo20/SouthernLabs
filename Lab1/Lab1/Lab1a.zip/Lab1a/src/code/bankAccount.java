/**
 * Represents a bank account with a balance in CAD, account number, and member's last name.
 * Provides methods to deposit, withdraw, and transfer funds between accounts.
 *
 * @author Lindokuhle Dubazane
 * @author Given Sitole
 *
 * @version 1.0
 */
class bankAccount
{
  private double balanceCAD;
   private final String accountNumber;
   private final String memberLastName;

    /**
     * Constructs a new bankAccount object.
     *
     * @param balanceCAD     The initial balance of the account in CAD.
     * @param accountNumber  The unique account number of the bank account.
     * @param memberLastName The last name of the account holder.
     */
   bankAccount(double balanceCAD,
               String accountNumber,
               String memberLastName)
   {
       this.balanceCAD      =  balanceCAD;
       this.accountNumber   =  accountNumber;
       this.memberLastName  =  memberLastName;
   }

    /**
     * Returns the current balance in CAD.
     *
     * @return The balance of the account in CAD.
     */
    public double getBalanceCAD()
    {
        return balanceCAD;
    }

    /**
     * Returns the account number of the bank account.
     *
     * @return The account number.
     */
    public String getAccountNumber()
    {
        return accountNumber;
    }

    /**
     * Returns the last name of the account holder.
     *
     * @return The last name of the member.
     */
    public String getMemberLastName()
    {
        return memberLastName;
    }

    /**
     * Withdraws the specified amount from the account.
     *
     * @param amountCAD The amount to be withdrawn from the account in CAD.
     */
    public void  withDraw(double amountCAD)
    {
        balanceCAD = balanceCAD - amountCAD;
    }

    /**
     * Deposits the specified amount into the account.
     *
     * @param amountCAD The amount to be deposited into the account in CAD.
     */
    public void deposit(double amountCAD)
    {
       balanceCAD = balanceCAD + amountCAD;
    }

    /**
     * Transfers the specified amount from this account to a recipient account.
     *
     * @param amountCAD        The amount to be transferred in CAD.
     * @param recipientAccount The bank account to receive the transferred funds.
     */
    public void transfer(double amountCAD, bankAccount recipientAccount)
    {
        recipientAccount.deposit(amountCAD);
        withDraw(amountCAD);
    }
}
